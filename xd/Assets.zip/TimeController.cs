using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class TimeController : MonoBehaviour
{
    // Start is called before the first frame update
    public Text countDown;
    public int TotalTime = 60;
    public int CurrentTime = 60;

    void Start()
    {
        StartCoroutine(Time());
    }

    IEnumerator Time()
    {
        while (TotalTime >= 0)
        {
            TimeSpan ts = TimeSpan.FromSeconds(CurrentTime);
            countDown.text = ts.ToString(@"mm\:ss");
            yield return new WaitForSeconds(1);
            CurrentTime--;
        }
    }

    void update()
    {
        
    }

}
