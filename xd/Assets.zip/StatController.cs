using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class StatController : MonoBehaviour
{
    // Start is called before the first frame update
    GameObject player;
    public Image HP1;
    public Image HP2;
    public Image HP3;
    float currentHP;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
    }

    // Update is called once per frame
    void Update()
    {
        currentHP = player.GetComponent<PlayerControler>().GetHP();
        if (currentHP == 3) {
            HP1.enabled = true;
            HP2.enabled = true;
            HP3.enabled = true;
        }
        else if (currentHP == 2)
        {
            HP1.enabled = true;
            HP2.enabled = true;
            HP3.enabled = false;
        }
        else if (currentHP == 1)
        {
            HP1.enabled = true;
            HP2.enabled = false;
            HP3.enabled = false;
        }
        else if (currentHP == 0)
        {
            HP1.enabled = false;
            HP2.enabled = false;
            HP3.enabled = false;
        }

    }
}
