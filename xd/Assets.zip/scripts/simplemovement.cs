using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class simplemovement : MonoBehaviour
{
    public float speed = 5f;
    float velocity;
    float velocityy;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        velocity = Input.GetAxisRaw("Horizontal") * Time.deltaTime;
        velocityy = Input.GetAxisRaw("Vertical") * Time.deltaTime;
        transform.Translate(new Vector2(velocity * speed, velocityy * speed));
    }
}
