using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoundController : MonoBehaviour
{
    float roundtime = 60f;

    // Update is called once per frame
    void Update()
    {
        roundtime -= Time.deltaTime;
        if(roundtime <= 0)
        {
            endRound();
        }
    }

    void endRound()
    {
        this.GetComponent<Spawner>().enabled = false;
        //Spawn Arrow pointing to exit
        //Spawn collider to next Scene
    }

    public void loadScene(int scenenum)
    {
        if(scenenum == 1)
        {
            //load scene 1
        }
        else if(scenenum == 2)
        {
            //load scene 2
        }
        else if(scenenum == 3)
        {
            //load scene 3
        }
    }
}
