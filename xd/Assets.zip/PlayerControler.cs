using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControler : MonoBehaviour
{
    Animator anim;
    float speed = 5;
    public GameObject wapon;


    int maxShot = 5;
    int currentShot = 0;

    int maxHP = 3;
    int currentHP = 3;

    bool protect = false;
    int currentProtectTime = 0;
    int totalProtectTime = 3;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (currentHP <= 0)
            currentHP = maxHP;

        if (protect)
        {
            StartCoroutine(Protection());
            Debug.Log("Protecting");
            protect = false;
        }
        //Movment
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");
        anim.SetFloat("Horizon", horizontalInput);
        anim.SetFloat("Vertical", verticalInput);

        transform.position = transform.position + new Vector3(horizontalInput * speed * Time.deltaTime, verticalInput * speed * Time.deltaTime);

            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                GameObject tmpObject = Instantiate(wapon);
                tmpObject.SetActive(true);
                tmpObject.GetComponent<WeaponController>().setPosition(transform.position);
                tmpObject.GetComponent<WeaponController>().setVerticaDirection(1);
                Destroy(tmpObject,5);
             }
            else if (Input.GetKeyDown(KeyCode.DownArrow))
            {
                GameObject tmpObject = Instantiate(wapon);
                tmpObject.SetActive(true);
                tmpObject.GetComponent<WeaponController>().setPosition(transform.position);
                tmpObject.GetComponent<WeaponController>().setVerticaDirection(-1);
                Destroy(tmpObject, 5);
            }
            else if (Input.GetKeyDown(KeyCode.LeftArrow))
            {
                GameObject tmpObject = Instantiate(wapon);
                tmpObject.SetActive(true);
                tmpObject.GetComponent<WeaponController>().setPosition(transform.position);
                tmpObject.GetComponent<WeaponController>().setHorizonDirection(-1);
                Destroy(tmpObject, 5);
            }
            else if (Input.GetKeyDown(KeyCode.RightArrow))
            {
                GameObject tmpObject = Instantiate(wapon);
                tmpObject.SetActive(true);
                tmpObject.GetComponent<WeaponController>().setPosition(transform.position);
                tmpObject.GetComponent<WeaponController>().setHorizonDirection(1);
                Destroy(tmpObject, 5);
            }
       
        
    }

    void OnCollisionEnter(Collision collision)
    {

        if (collision.gameObject.tag == "Enermy" && protect == false) {
            currentHP -= 1;
            protect = true;
        }

    }


    public float GetHP()
    {
        return currentHP;
    }
    IEnumerator Protection()
    {

            yield return new WaitForSeconds(totalProtectTime);

    }


}